<?php 

include("header.php");
?>
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Welcome to administrator</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active">Admin Home</li>
                        </ol>
                        <div class="card mb-4">
                            <div class="card-body">
                                <p class="mb-0">
                                     
                                </p>
                            </div>
                        </div>
					</div>
                </main>
<?php 

include("footer.php");
?>